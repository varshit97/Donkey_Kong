from setuptools import setup,find_packages
from distutils.command.install import INSTALL_SCHEMES

setup(
    packages=['.'],
)
